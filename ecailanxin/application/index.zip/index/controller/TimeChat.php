<?php
namespace app\index\controller;
use think\Controller;
use think\Request;
use think\Db;
use think\File;
use app\index\model\WxPay;
use app\index\controller\AliyunPay;
Class TimeChat extends Controller
{

    //通讯demo

    

}