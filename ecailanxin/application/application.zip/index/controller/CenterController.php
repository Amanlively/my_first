<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Request;
class CenterController extends Controller
{
//	个人中心显示
    public function center()
    {
        $userid = session('userid');
    	if(session('userid') == null || session('phone') == null){
    		return redirect('/index/login/login');
    	}else{
    	$row = Db::table('ycl_user')->where('id',session('userid'))->find();
    	$this->assign('row',$row);
    	$this->assign('fromid',$userid);
		return $this->fetch();
    	}
    }
    
//  我的余额
	public function money()
    {
    	$rowset = Db::table('ycl_user')->where('id',session('userid'))->find();
    	$query = Db::table('ycl_order')->where('buy_id',$rowset['id'])->where('sales_return',1)->order('add_time desc')->select();
    	$this->assign('query',$query);
    	$this->assign('rowset',$rowset);
		return $this->fetch();
    }
    
//  提现申请
	public function putforward()
    {
		return $this->fetch();
    }
    
    public function message()
    {
        $userid = session('userid');

        $this->assign('fromid',$userid);
		return $this->fetch();
    }
    
    // 提现审核
    public function txaudit()
    {
    	$username = input('post.username');
    	$yhkh     = input('post.yhkh');
    	$khh      = input('post.khh');
    	$txmoney  = input('post.txmoney');
    	$row = Db::table('ycl_user')->where('id',session('userid'))->find();
    	$xj       = $row['money'] - $txmoney;
    	if($username == null) {
    		$data['status'] = -1;
			$data['info'] = "账户名不能为空";
			$msg = json_encode($data);
			echo $msg;
			return;
    	}
    	if($username !== $row['username']) {
    		$data['status'] = -2;
			$data['info'] = "账户名有误";
			$msg = json_encode($data);
			echo $msg;
			return;
    	}
    	if($yhkh == null) {
    		$data['status'] = -3;
			$data['info'] = "银行卡号不能为空";
			$msg = json_encode($data);
			echo $msg;
			return;
    	}
    	$preg_bankcard='/^(\d{15}|\d{16}|\d{19})$/isu';
 		if(!preg_match($preg_bankcard,$yhkh)){
 			$data['status'] = -8;
			$data['info'] = "银行卡号,格式有误!";
			$msg = json_encode($data);
			echo $msg;
			return;
 		}
    	if($khh == null) {
    		$data['status'] = -5;
			$data['info'] = "开户行不能为空";
			$msg = json_encode($data);
			echo $msg;
			return;
    	}
    	if($txmoney == null) {
    		$data['status'] = -6;
			$data['info'] = "提现金额不能为空";
			$msg = json_encode($data);
			echo $msg;
			return;
    	}
    	$arr = array(
    	'uid' => session('userid'),
    	'username' => $username,
    	'yhkh'     => $yhkh,
    	'khh'     => $khh,
    	'tx_money' => $txmoney,
    	'is_sh'	  => 0,
    	'add_time'=> time()
    	);
    	$query = Db::table('ycl_withdraw')->insert($arr);
    	if ($query) {
    		Db::table('ycl_user')->where('id',session('userid'))->setField('money',$xj);
    		$data['status'] = 1;
			$data['info'] = "提现申请成功";
			$msg = json_encode($data);
			echo $msg;
			return;
    	} else {
    		$data['status'] = -7;
			$data['info'] = "提现申请失败";
			$msg = json_encode($data);
			echo $msg;
			return;
    	}
    }

     
}
