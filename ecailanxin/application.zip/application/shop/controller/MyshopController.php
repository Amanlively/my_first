<?php
namespace app\shop\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\File;
class MyshopController extends Controller{
	
	public function myshop(){
		   
			$one1 = input('param.one'); //接收一级分类过来的ID
    		$two1 = input('param.two'); //接收二级分类过来的ID
			$rowset = Db::table('ycl_shop_info')->where('uid',session('userid'))->find();
//			print_r($rowset);die;
			$shop = $rowset['id'];


    	    $this->assign('rowset',$rowset);
 		
  			$one = Db::table('ycl_category_one')->select();//查询一级分类表
    		$this->assign('one',$one);
    		
    		$two = Db::table('ycl_category_two')->where('up_catid',$one1)->select(); //查询二级分类表
    		$this->assign('two',$two);
    		
    		if($two1 !== null){
    		$cai = Db::table('ycl_goods')->where('cattwoid',$two1)->where('shopid',$rowset['id'])->select();
    	    $this->assign('cai',$cai);
    	
    		}else{
    		$cai = Db::table('ycl_goods')->where('catoneid',$one1)->where('shopid',$rowset['id'])->select();	
//  		$cai = Db::table('ycl_goods')->where('shopid',$rowset['id'])->select();
    	    $this->assign('cai',$cai);
    	    }
    	    if($one1 == null && $two1 == null){
    	    	$cai = Db::table('ycl_goods')->where('shopid',$rowset['id'])->select();
    	    	$this->assign('cai',$cai);
    	    }
    		$this->assign('one1',$one1);
    		$this->assign('shop',$shop);
		
			return $this->fetch();
		
	}
	public function businesslocation(){ //商家评价
		$shop    = input('param.id'); //店铺ID
		//$lun     = input('param.lun'); //评论筛选
//		print_r($lun);
		$rowset1 = Db::table('ycl_collect')->where('shop_id',$shop)->find(); //搜索收藏店铺
		$this->assign('rowset1',$rowset1);
		$im = Db::table('ycl_comment')->where('shop_id',$shop)->find();
		$userimg = Db::table('ycl_user')->where('id',$im['uid'])->find(); //搜索用户头像
//		print_r($userimg);die;
		$this->assign('userimg',$userimg);
		
		$xin = Db::table('ycl_comment')->where('shop_id',$shop)->order('add_time desc')->select();//查看该店铺最新评论
		$this->assign('xin',$xin);
		$di = Db::table('ycl_comment')->where('shop_id',$shop)->order('di')->select();//查看该店铺最低分
		$this->assign('di',$di);
		$img     = Db::table('ycl_comment')->where('pingimg','not null')->where('shop_id',$shop)->select();//查看该店铺带图片所有评论
		$num1 = count($img);
		$this->assign('img',$img);
		$this->assign('num1',$num1);
//		print_r($img);
		$rowset = Db::table('ycl_shop_info')->where('id',$shop)->find(); 
		$time = date('H');
			if($time >= $rowset['open_time'] && $time < $rowset['close_time']){
				$kai = '营业中' ;
			}else{
				$kai = '已打烊' ;
			}
		$this->assign('kai',$kai);
		$con = Db::table('ycl_comment')->where('shop_id',$shop)->select();//查看该店铺所有评论
		$num = count($con); //评论数量
		$this->assign('num',$num);
//		print_r($num);
		$this->assign('con',$con);
    	$this->assign('rowset',$rowset);
 		$this->assign('shop',$shop);
		return $this->fetch();
	}
	public function businessevaluation(){ //商家信息
		$shop = input('param.id'); //店铺ID
		$rowset1 = Db::table('ycl_collect')->where('shop_id',$shop)->find(); //搜索收藏店铺
		$this->assign('rowset1',$rowset1);
		
		$rowset = Db::table('ycl_shop_info')->where('id',$shop)->find(); 
    	$this->assign('rowset',$rowset);
    	$time = date('H');
//  	print_r($time);
			if($time >= $rowset['open_time'] && $time < $rowset['close_time']){
				$kai = '营业中' ;
			}else{
				$kai = '已打烊' ;
			}
		$this->assign('kai',$kai);
 		$this->assign('shop',$shop);
		return $this->fetch();
	}

	public function modifyproduct($shopid){ //添加商品显示页面
//		print_r($shopid);die;
		$one = Db::table('ycl_category_one')->select();//搜索一级分类
		$this->assign('one',$one);
		
		$two = Db::table('ycl_category_two')->select();//搜索二级分类
		$this->assign('two',$two);
		
		$brand = Db::table('ycl_brand')->select();//搜索品牌表
		$this->assign('brand',$brand);
		
		$gg = Db::table('ycl_spec')->select();//搜索规格表
		$this->assign('gg',$gg);
		
		$gg1 = Db::table('ycl_spec')->select();//搜索规格表
		$this->assign('gg1',$gg1);
		$this->assign('shopid',$shopid);
		 return $this->fetch();
	}
	
	
	public function goodssave(Request $request,$shopid){ //保存商品
		
		$data['shopid']      = $shopid;//店铺id
		$data['goodsname']   = input('param.name');//商品名字
		$data['goodsprice']  = input('param.goodsprice'); //商品价格
		$data['goodsgg']     = input('param.gg'); //商品规格
		$data['catoneid']    = input('param.one'); //一级分类
		$data['cattwoid']    = input('param.two');//二级分类
		$data['introduce']   = input('param.introduce');//商品描述. 介绍
		$data['stock']       = input('param.stock');//库存
		$data['stockgg']     = $data['goodsgg'];//库存规格
		$data['goodsarea']   = input('param.goodsarea');//产地
		$data['brand_id']    = input('param.brand');//商品品牌
		$data['discount']    = input('param.discount');//折扣
		$data['alias']       = input('param.alias');//别名
		$data['addtime']     = time();
		$data['city']        = Db::table('ycl_shop_info')->where('uid',session('userid'))->value('city');//别名
		$file = $request->file('goodspic');
//		print_r($file);die;
			if($file){
				$info=$file->move ( \ENV::get('root_path'). '/public/static/uploads/goodspic' );
				if($info){
					$data['goodspic']=$info->getSaveName();
//					print_r($data);die;
				}
			}
		Db::table('ycl_goods')->insert($data);
		return $this->redirect('/shop/myshop/myshop/id/' .$shopid);
	}
	
	public function goodsedit($id,$shopid){
//		print_r($shopid);
		$this->assign('shopid',$shopid);
		
		$row = Db::table('ycl_goods')->where('id',$id)->find();
		$this->assign('row',$row);
		
		$one = Db::table('ycl_category_one')->select();//搜索一级分类
		$this->assign('one',$one);
		
		$two = Db::table('ycl_category_two')->select();//搜索二级分类
		$this->assign('two',$two);
		
		$brand = Db::table('ycl_brand')->select();//搜索品牌表
		$this->assign('brand',$brand);
		
		$gg = Db::table('ycl_spec')->select();//搜索规格表
		$this->assign('gg',$gg);
		
		$gg1 = Db::table('ycl_spec')->select();//搜索规格表
		$this->assign('gg1',$gg1);
		return $this->fetch();
	}
	public function goodsupdate(Request $request,$id,$shopid){
		$data['shopid']      = $shopid;//店铺id
		$data['goodsname']   = input('param.name');//商品名字
		$data['goodsprice']  = input('param.goodsprice'); //商品价格
		$data['goodsgg']     = input('param.gg'); //商品规格
		$data['catoneid']    = input('param.one'); //一级分类
		$data['cattwoid']    = input('param.two');//二级分类
		$data['introduce']   = input('param.introduce');//商品描述. 介绍
		$data['stock']       = input('param.stock');//库存
		$data['stockgg']     = $data['goodsgg'];//库存规格
		$data['goodsarea']   = input('param.goodsarea');//产地
		$data['brand_id']    = input('param.brand');//商品品牌
		$data['discount']    = input('param.discount');//折扣
		$data['alias']       = input('param.alias');//别名
		$data['addtime']     = time();
		
		$file = $request->file('goodspic');
//		print_r($file);die;
			if($file){
				$info=$file->move ( \ENV::get('root_path'). '/public/static/uploads/goodspic' );
				if($info){
					$data['goodspic']=$info->getSaveName();
//					print_r($data);die;
				}
			}
		$ww = Db::table('ycl_goods')->where('id',$id)->update($data);
		return $this->redirect('/shop/myshop/myshop/id/' .$shopid);
		
	}
	
	public  function del($id,$shopid){
		
//		print_r($shopid);die;
		Db::table('ycl_goods')->where('id',$id)->delete();
		return $this->redirect('/shop/myshop/myshop/id/'.$shopid);
	}







	//显示尾货列表
	public function tailgoodsarea() {
		if(session('userid') == null) {
			return $this->redirect(url('/user/login/login'));
		} else {
			$rowset = Db::table('ycl_shop_info')->where('uid',session('userid'))->find();
			$goods = Db::table('ycl_goods')->where('shopid',$rowset['id'])->where('tail',1)->select();
			$gg = Db::table('ycl_spec')->select();
			$goodsgg = array_column($gg,'name','id');
			$this->assign('goodsgg',$goodsgg);
			$this->assign('rowset',$rowset);
			$this->assign('goods',$goods);
		}
		
		return $this->fetch();
	}
	
	//添加尾货
     public function addinggoods() {
     	$id = input('param.goodsid');
		$row = Db::table('ycl_goods')->where('id',$id)->find();
//		print_r($row);die;
		$this->assign('row',$row);
		$this->assign('goodsid',$id);
		return $this->fetch();
	}
	// 添加尾货保存
	public function tailsave() {
		$id = input('param.id');
		$number = input('param.number');
		$price = input('param.price');
		$arr = array(
		'stock' => $number,
		'goodsprice' => $price,
		'tail' => 1
		);
		Db::table('ycl_goods')->where('id',$id)->update($arr);
		return $this->redirect(url('/shop/myshop/tailGoodsArea'));
	}
	
	
	
	public function details(){  //菜品详情预览页
			$id = input('param.goodsid');//商品id
			$rowset1 = Db::table('ycl_collect')->where('uid',session('userid'))->where('goods_id',$id)->find();
			$this->assign('rowset1',$rowset1);
			$yi=Db::table('ycl_spec')->select(); //将规格表的 id 转为name显示
			$gg = array_column($yi,'name','id');
			$this->assign('gg',$gg);
			
			$er=Db::table('ycl_brand')->select(); //将品牌表的 id 转为name显示
			$pin = array_column($er,'brand_name','id');
			$this->assign('pin',$pin);
			
 			$rowset = Db::table('ycl_goods')->where('id',$id)->find(); 
    	    $this->assign('rowset',$rowset);
//			print_r($rowset);die;
    	    //商品所属商家
            $shopid = Db::name('goods')->where('id',$id)->value('shopid');
            //店主id
            $userid = Db::name('shop_info')->where('id',$shopid)->value('uid');
            $this->assign('toid',$userid);
    	    
    	
		    return $this->fetch();
			}	
		public function liandong(){
			$cate_id = input('post.cate_id');
			print_r($cate_id);die;
		}
	
}




