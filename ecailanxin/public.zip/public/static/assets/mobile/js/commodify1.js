$(document).ready(function(){
	$(".classification-left-li:first-child").css({
		"color":"#B6B6B6",
		"background-color":"white"
	});
});

$(".classification-left-li").click(function(){
	$(this).css({
		"background-color":"white",
		"color":"#c6c6c6"
	}).siblings("li").css({
		"color":"#B6B6B6",
		"background-color":""
	});
});
$('.add').click(function(){
	
	var imvalue = Number($(this).siblings('input').val());
	$(this).siblings('input').val(imvalue+1);
})
$('.reduce').click(function(){
	var imvaluelater = Number($(this).siblings('.imshow').children('input').val());
	$(this).siblings('.imshow').children('input').val(imvaluelater-1);
	if ($(this).siblings('.imshow').children('input').val()<0) {
		alert("选择必须大于0");
		$(this).siblings('.imshow').children('input').val(0);
	}
})
$(function() {
	var offset = $(".busidetail-foot-img").offset(); //结束的地方的元素
	$(".rightimg").click(function(event) { //是$("#rightimg")这个元素点击触发的 开始动画的位置就是这个元素的位置为起点
		var addcar = $(".busidetail-body-left");
		var img = addcar.find('img').attr('src');
		var flyer = $('<img class="u-flyer" src="' + img + '">');
		flyer.fly({
			start: {
				left: event.clientX,
				top: event.clientY
			},
			end: {
				left: offset.left+10,
				top: offset.top+10,
				width: 0,
				height: 0
			},
			onEnd: function() {
				$("#msg").show().animate({
					width: '250px'
				}, 400).fadeOut(1000);
				addcar.css("cursor", "default").removeClass('orange').unbind('click');
				this.destory();
			}
		});
//		$(".busidetail-foot-img").attr('src',"__STATIC__/assets/mobile/img/lanzi_active.png");
//		$(".busidetail-foot").css({
//			'background-color':'#61bc67',
//			'color':'white'
//		});
		
//		var ival=$(".busidetail-foot span").text();
		
//		var thisprice=Number($(this).parent().siblings('b').find('span').text());//获取当前商品价格
//		var thisname=$(this).parent().parent().siblings('h4').text();
//		alert(thisname);
//		alert(thisprice);
//		var ivalint=Number(ival);
//		var totalprice=thisprice + ivalint;
//		$(".busidetail-foot span").html(totalprice.toFixed(2));
		
//		if(totalprice>=20){
//			$(".busidetail-foot-right").html("去付款");
//			$(".busidetail-foot-right").css({
//				'background-color':'#ffa508'
//			})
//		}
		
		var thisprice=Number($(this).parent().siblings('b').find('span').text());//获取当前商品价格
		var thisname=$(this).parent().parent().siblings('h4').text();
		
//		alert(thisname);
		$.ajax({
			type: "POST",
			url: "/index/companydata/save9",
			data: {
				"thisprice":thisprice,
				"thisname":thisname,
			},
			datatype:'json',
			async: true,
			error: function(request) {
				alert("其他错误,请联系客服");
			},
			success: function(data) {
				var data = JSON.parse(data);
				var pei =data['pei'];
				var totalprice=data['zj'];
				window.location.reload();
				if(totalprice>0){
					$(".busidetail-foot span").html(totalprice.toFixed(2));//
					$(".busidetail-foot-img").attr('src',"__STATIC__/assets/mobile/img/lanzi_active.png");
					$(".busidetail-foot").css({
						'background-color':'#61bc67',
						'color':'white'
					});
					if(totalprice>=40){
						$(".busidetail-foot-right").html("去付款");
						$(".busidetail-foot-right").css({
							'background-color':'#ffa508'
						})
					}
				}
			}  
		});
		
		
	});
});