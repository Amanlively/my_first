//$(document).ready(function(){
//	$(".classification-left-li:first-child").css({
//		"color":"#B6B6B6",
//		"background-color":"white"
//	});
//});

$(".classification-left-li").click(function(){
	$(this).css({
		"background-color":"white",
		"color":"#c6c6c6"
	}).siblings("li").css({
		"color":"#B6B6B6",
		"background-color":""
	});
});
	
//辅助方法--单击购物车中的"+"  "-"  "x"按钮是找到相关商品所在td,以jQuery对象返回  
//function findStock(btn){
//  var name = $(btn).parent().siblings().eq(0).html();//获取商品名字  
//  //注意table默认有行分组,若此处使用 $("#table1>tr:gt(0)")则找不到任何tr  
//  var $trs = $("#table1>tbody>tr:gt(0)");  
//  for(var i=0;i<$trs.length;i++){  
//    var fName = $trs.eq(i).children().eq(0).html();  
//    if(name == fName){//找到匹配的商品  
//      return $trs.eq(i).children().eq(3);
//    }  
//  }  
//}     
  //增加"+"功能  
function increase(btn){  
    //购物车数据改变  
    var $td = $(btn).prev();
    var num = parseInt($td.val());//number
    //num此时为number类型(在计算时会自动转换为number类型)  
    $td.val(++num);  
    //获取单价,再加计算前要先转换为number类型  
	var name = $(btn).parent().siblings().eq(0).html();//获取商品名字  
	var $divs = $(".busidetail-body:gt(0)");//获取节点
	$(".busidetail-body").each(function(){
		var fName=$(this).children().eq(1).children().eq(0).text();
		var price=Number($(this).children().eq(1).children().eq(4).find('span').text())
		if(name==fName){
			var thisprice=price*num;//计算商品价格
			$(btn).parent().siblings().eq(1).find('span').html(thisprice.toFixed(2));
		}
	})
    //总计功能  
    total();  
}
//减少"-"功能  
function decrease(btn){  
    //购物车数据改变  
    var num = parseInt($(btn).next().val());//number
    if(num<1){
    	if(num==0){
    	//$("#goods").remove($(this));
    	$(btn).parent().parent().remove();
    	return;
    	}
    }
    //num此时为number类型(在计算时会自动转换为number类型)  
    $(btn).next().val(--num);
    //获取单价,再加计算前要先转换为number类型  
	var name = $(btn).parent().siblings().eq(0).html();//获取商品名字  
	var $divs = $(".busidetail-body:gt(0)");//获取节点
	$(".busidetail-body").each(function(){
		var fName=$(this).children().eq(1).children().eq(0).text();
		var price=Number($(this).children().eq(1).children().eq(4).find('span').text())
		if(name==fName){
			var thisprice=price*num;//计算商品价格
			$(btn).parent().siblings().eq(1).find('span').html(thisprice.toFixed(2));
		}
	})
    //总计功能  
    total();
}

//总计功能  
function total(){
  //获取所有购物车中的trs
  var $trs = $("#goods tr");  
  var amount = 0;  
  for(var i=0;i<$trs.length;i++){  
    var money = Number($trs.eq(i).children().eq(1).find('span').text());  
    amount += money;
//  alert(typeof(amount));
    var lastamount = amount.toFixed(2);
  }
  //写入总计栏  
	$("#total").html(lastamount);
	if(lastamount>=20){
		$(".busidetail-foot-right").html("加入我的菜");
		$(".busidetail-foot-right").css({
			'background-color':'#ffa508'
		})
	}else{
		$(".busidetail-foot-right").html("￥20起送");
		$(".busidetail-foot-right").css({
			'background-color':'#535356'
		})
	}
}
function del(btn){  
    //清空改行商品列表  
    $("#goods").children().remove();  
    $("#popover").hide();
    $(".mui-backdrop").hide();
 	$("#total").html(0);
}
//点击当前商品添加，划弧线，计算总价，改变样式，添加购物栏
$(".rightimg").click(function(event) { 
    var addcar = $(this).parent().parent().parent().siblings();
	var img = addcar.find('img').attr('src');
	var offset = $(".busidetail-foot-img").offset(); //结束的地方的元素
	var flyer = $('<img class="u-flyer" src="' + img + '">');
	flyer.fly({
		start: {
			left: event.clientX,
			top: event.clientY
		},
		end: {
			left: offset.left+10,
			top: offset.top+10,
			width: 0,
			height: 0
		},
		onEnd: function() {
			$("#msg").show().animate({
				width: '250px'
			}, 400).fadeOut(1000);
			addcar.css("cursor", "default").removeClass('orange').unbind('click');
			this.destory();
		}
	});
	var img_url="/static/assets/mobile/img/footer3";
//	var img_url1=img_url.replace(/.png|_active.png/,'.png');
//	alert(img_url1);
	$(".busidetail-foot-img").attr('src',img_url+"_active.png");
	$(".busidetail-foot").css({
		'background-color':'#61bc67',
		'color':'white'
	});
	//var totalprice=$(".busidetail-foot span").text();
	var thisprice = Number($(this).parent().siblings('b').children().text().trim());//获取当前商品价格
	var thisname = $(this).parent().parent().siblings('h4').text();//获取当前选择的商品名
	
	var goodsID =$(this).siblings('input').eq(0).val();//商品id
	var shopid =$(this).siblings('input').eq(1).val();//店铺id
	
	var amount1 = Number($("#total").html());
	Number(amount1 += thisprice);
	$("#total").html(amount1.toFixed(2));
	if(amount1 >= 20){
		$(".busidetail-foot-right").html("加入我的菜");
		$(".busidetail-foot-right").css({
			'background-color':'#ffa508'
		})
	}else if(amount1 == 0.00){
		$(".busidetail-foot-right").html("￥20起送");
		$(".busidetail-foot-right").css({
			'background-color':'#535356'
		})
	}
	//在添加之前确定该商品在购物车中是否存在,若存在,则数量+1,若不存在则创建行  
	var $trs = $("#goods>tr");  
    for(var i=0;i<$trs.length;i++){  
      var $gtds = $trs.eq(i).children();
      var gName = $gtds.eq(0).html();  
      if(thisname == gName){//判断商品名在购物车中是否存在；若存在  
        var num = parseInt($gtds.eq(2).children().eq(1).val());  
            $gtds.eq(2).children().eq(1).val(++num);//数量+1  
//      alert(num1);
        //金额从新计算  
        $gtds.eq(1).children().html(thisprice*num);  
        return;//后面代码不再执行  
      }  
    }
     //若不存在,创建后追加  
    var li =  
        "<tr>"+
			"<td width='40%'>"+thisname+"</td>"+
			"<td width='30%'>￥<span>"+thisprice+"<span></td>"+
			"<td width=	'30%' align='center'>"+  
        	"<input type='button' value='-' onclick='decrease(this);'/> "+  
        	"<input type='text' name='count' size='3' readonly value='1'/> "+  
        	"<input type='button' value='+' onclick='increase(this);'/>"+
        	"<input type='hidden' name='goodsid' value='"+ goodsID +"' /> "+ 
        	"<input type='hidden' name='shopid' value='"+ shopid +"' /> "+ 
        	"<input type='hidden' name='thisname' value='"+ thisname +"' /> "+
        	"<input type='hidden' name='thisprice' value='"+ thisprice +"' /> "+
        	"</td>"
    	"</tr>";
    //追加到#goods后面    goodsid['"+ goodsID +"']
    $("#goods").append($(li));
    
    //alert($("#goods").children().children().eq(1).find('span').text());
    //总计功能  
});	
